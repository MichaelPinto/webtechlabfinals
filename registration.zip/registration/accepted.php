<?php
include("db_connection.php");
    
    if(isset($_GET['accept'])){
        $id = intval($_GET['accept']);
        $result = mysqli_query($dbcon,"SELECT * FROM service_provider WHERE service_id = $id");
        
        mysqli_autocommit($dbcon, false);
        mysqli_query($dbcon,"insert into service_providers select * from service_provider where service_id = $id");
        mysqli_query($dbcon, "delete from service_provider where service_id = $id");
        mysqli_commit($dbcon);
        
            echo "<script>window.open('index.php',)</script>";
    }