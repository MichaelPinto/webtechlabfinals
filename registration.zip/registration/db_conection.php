<?php    
$dbcon = mysqli_connect("localhost","root","") or die ("could not connect to mysql"); 
mysqli_select_db($dbcon,"webtechlabgrp3") or die ("no database");  
?>  