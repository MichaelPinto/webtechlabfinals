<?php  
session_start();//session starts here  
  
?>  
  
  
  
<html>  
<head lang = "en">  
    <meta charset = "UTF-8">  
    <link type = "text/css" rel = "stylesheet" href = "">  
    <title>Login</title>  
</head>  
<style>  
    .login-panel {  
        margin-top: 150px;  
  
</style>  
  
<body>  
  
  
<div class = "container">  
    <div class = "row">  
        <div class = "col-md-4 col-md-offset-4">  
            <div class = "login-panel panel panel-success">  
                <div class = "panel-heading">  
                    <h3 class = "panel-title">Sign In - Admin</h3>  
                </div>  
                <div class = "panel-body">  
                    <form role = "form" method = "post" action = "admin_login.php">  
                        <fieldset>  
                            <div class = "form-group"  >  
                                <input class = "form-control" placeholder = "Username" name = "username" type = "text" autofocus>  
                            </div>  
                            <div class = "form-group">  
                                <input class = "form-control" placeholder = "Password" name = "password" type = "password" value = "">  
                            </div>  
  
  
                                <input class = "btn btn-lg btn-success btn-block" type = "submit" value = "login" name = "admin_login" >  
  
                            <!-- Change this to a button or input when using this as a form -->  
                          <!--  <a href="index.html" class="btn btn-lg btn-success btn-block">Login</a> -->  
                        </fieldset>  
                    </form>
					<center><br></b><a href = "login.php">Back</a></center>					
				</div>  
            </div>  
        </div>  
    </div>  
</div>  
  
  
</body>  
  
</html>  
  
<?php  
  
include("database/db_conection.php");  
  
//admin login
if(isset($_POST['admin_login']))//this will tell us what to do if some data has been post through form with button.  
{  
    $username = $_POST['username'];  
    $password = $_POST['password'];
  
    $admin_query = "select * from admin where username='$username' AND password='$password'";  
  
    $run_query = mysqli_query($dbcon,$admin_query);  
  
    if(mysqli_num_rows($run_query)>0)  
    {  
  
        echo "<script>window.open('index.php','_self')</script>"; 
		$_SESSION['username'] = $username;
    }  
    else {echo"<script>alert('Admin Details are incorrect..!')</script>";}  
  
}
	
  
?>  