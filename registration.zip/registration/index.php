<?php  
session_start();  
  
if(!$_SESSION['username'])  
    {  
        header("Location: admin_login.php");
    } 
?>


<!DOCTYPE html>
<html lang = "en">
<head>
<meta charset = "utf-8">
<meta name = "viewport" content = "width=device-width, initial-scale = 1">
<meta name = "description" content = "">
<meta name = "author" content = "">
<title>Aling bebe - Search </title>
<!-- Bootstrap Core CSS -->
<link rel = "stylesheet" href = "" type = "text/css">
<link rel = "stylesheet" href = "" type = "text/css">
    
</head>
<body id = "page-top">
<nav id = "mainNav" class = "navbar navbar-default navbar-fixed-top">
<div class = "container">
	<div class = "navbar-header">
		<button type = "button" class = "navbar-toggle collapsed" data-toggle = "collapse" data-target = "#bs-example-navbar-collapse-1">
		<span class = "sr-only">Toggle navigation</span>
		<span class = "icon-bar"></span>
		<span class = "icon-bar"></span>
		<span class = "icon-bar"></span>
		</button>
		<a class = "navbar-brand page-scroll" href = "#page-top"><img src = "" alt = ""></a>
	</div>
    
	<!-- Collect the nav links, forms, and other content for toggling -->
	<div class = "collapse navbar-collapse" id = "bs-example-navbar-collapse-1">
		<ul class = "nav navbar-nav navbar-right">
			<li>
			<a class = "page-scroll" href = "#dashboard">Transactions</a>
			</li>
			<li>
			<a class = "page-scroll" href = "#request">Feedback & Services</a>
			</li>
			<li>
			<a class = "page-scroll" href = "#client">Request</a>
			</li>
            <li>
			<a class = "page-scroll" href = "#accounts">Accounts</a>
			</li>
			<li>
			<a href = "logout.php">Logout</a>
			</li>
		</ul>
	</div>
	<!-- /.navbar-collapse -->
</div>
<!-- /.container -->
</nav>
<!-- Section Services
================================================== -->
<section id = "dashboard">
<div class = "container">
<div class = "row">
	<div class = "col-lg-12 text-center">
		<h2 class = "section-heading">WELCOME ADMIN!</h2>
		<hr class = "primary">
	</div>

</div>
</div>
    
<!-- /.carousel -->

<!-- Section About
================================================== -->
<section id = "dashboard">
<div class = "container">
	<div class = "row">
		<div class = "col-lg-10 col-lg-offset-1 text-center">

				<h1 align = "center">Transactions</h1>
             	<table class = "table table-bordered table-hover table-striped" style = "table-layout: fixed">  
				<thead>   
		  
				<tr>
					<th>Service Provider</th>
					<th>Customer</th>  			
					<th>Address</th>  
					<th>Service Availed</th>
					<th>Status</th>
					<th>Remarks</th>
					<th>Date</th>
				</tr>  
				</thead>  
		  
				<?php  
					include("db_conection.php");  
					$view_salon_query="select * from transactions";//select query for viewing users.
					$run = mysqli_query($dbcon,$view_salon_query);//here run the sql query.  
			  
					while($row = mysqli_fetch_array($run))//while look to fetch the result and store in a array $row.  
					{  
						$request_id = $row[0];  
						$sp_id = $row[1];
						$cust_id = $row[2];			  
						$serviceDesc = $row[3];
						$status = $row[4];
						$remarks = $row[5];
						$date = $row[6];

				?>  
		  
				<tr>     
					<td><?php echo $request_id;  ?></td>   
					<td><?php echo $sp_id;  ?></td>
					<td><?php echo $cust_id;  ?></td>
					<td><?php echo $serviceDesc ?></td>			
					<td><?php echo $status;  ?></td> 
					<td><?php echo $remarks;  ?></td>
					<td><?php echo $date;  ?></td>					
				</tr>  
		  
				<?php } ?>  
		  
			</table>    
	</div>
</div>
</div>
</section>

<section id = "dashboard">
<div class = "container">
	<div class = "row">
		<div class = "col-lg-10 col-lg-offset-1 text-center">

				<h1 align = "center">Costume Choices</h1>
             	<table class = "table table-bordered table-hover table-striped" style = "table-layout: fixed">  
				<thead>   
		  
				<tr>
					<th>Customer Id</th> 
					<th>Costume Availed</th>
					<th>Date</th>
					<th>SP Id</th>
					<th>Claim Date</th>
					
				</tr>  
				</thead>  
		  
				<?php  
					include("db_conection.php");  
					$view_salon_query = "select * from products";//select query for viewing users.
					$run = mysqli_query($dbcon,$view_salon_query);//here run the sql query.  
			  
					while($row = mysqli_fetch_array($run))//while look to fetch the result and store in a array $row.  
					{  
						$request_id = $row[0];  
						$custom_id = $row[1];			  
						$serviceOffer = $row[2];
						$dateAvail = $row[3];
						$service_id = $row[4];
						$claim_date = $row[5];

				?>  
		  
				<tr>     
					<td><?php echo $user_id;  ?></td>   
					<td><?php echo $service_id;  ?></td>
					<td><?php echo $costume_availed;  ?></td>
					<td><?php echo $service_id ?></td>			
					<td><?php echo $claim_date;  ?></td> 				
				</tr>  
		  
				<?php } ?>  
		  
			</table>    
	</div>
</div>
</div>
</section>

<section id = "request">
<div class = "container">
	<div class = "row">
		<div class = "col-lg-10 col-lg-offset-1 text-center">

				<h1 align = "center">Products</h1>
             	<table class = "table table-bordered table-hover table-striped" style = "table-layout: fixed">  
				<thead>   
		  
				<tr>
					<th>Product Id</th> 			
					<th>Product Description</th>  
					<th>Price</th>
				</tr>  
				</thead>  
		  
				<?php  
					include("db_conection.php");  
					$view_salon_query = "select * from products";//select query for viewing users.
					$run = mysqli_query($dbcon,$view_product_query);//here run the sql query.  
			  
					while($row = mysqli_fetch_array($run))//while look to fetch the result and store in a array $row.  
					{  
						$product_id = $row[0];  
						$product_name = $row[1];			  
						$product_price = $row[2];

				?>  
		  
				<tr>     
					<td><?php echo $product_id;  ?></td>   
					<td><?php echo $product_name;  ?></td>
					<td><?php echo $product_price;  ?></td> 
				</tr>  
		  
				<?php } ?>  
		  
			</table>    
	</div>
</div>
</div>
</section>
    
<!-- Section Timeline
================================================== -->
<section id = "client">
<div class = "container">
<div class = "row">
		<div class = "table-scrol">  
		<h1 align = "center">Customers Request for Account</h1>
	  
		<div class = "table-responsive"><!--this is used for responsive display in mobile and other devices-->  
	  
	  
		<table class = "table table-bordered table-hover table-striped" style = "table-layout: fixed">  
				<thead>   
		  
				<tr>
					<th>First Name</th>					
					<th>Last Name</th>
					<th>Username</th>
					<th>Gender</th>					
					<th>Address</th> 
					<th>E-mail</th>
					<th>Country</th>							
					<th>Contact Number</th>
					<th>Action</th>
				</tr>  
				</thead>  
		  
				<?php  
					include("db_conection.php");  
					$view_salon_query = "select * from users";//select query for viewing users.
					$run = mysqli_query($dbcon,$view_users_query);//here run the sql query.  
			  
					while($row = mysqli_fetch_array($run))//while look to fetch the result and store in a array $row.  
					{  

						$user_id = $row[0];
						$firstname = $row[1];						
						$lastname = $row[2];
						$username = $row[3];
						$gender = $row[5];
						$address = $row[6];
						$email = $row[7]; 
						$country = $row[8];
						$contact_no = $row[9];
				?>  
		  
				<tr>  
		<!--here showing results in the table -->  

					<td><?php echo $firstname;  ?></td>
					<td><?php echo $lastname;  ?></td>    
					<td><?php echo $username;  ?></td> 
					<td><?php echo $gender;  ?></td>
					<td><?php echo $address;  ?></td>
					<td><?php echo $email;  ?></td> 
					<td><?php echo $country;  ?></td>
					<td><?php echo $contact_no;  ?></td>			
					
					<td><a href = "accept.php?accept = <?php echo $customer_id ?>"><button onclick = "block_none()">Accept</button></a>
					<a href = "delete_client.php?del = <?php echo $customer_id ?>"><button onclick = "block_none()">Reject</button></a></td> <!--btn btn-danger is a bootstrap button to show danger-->  
					
				<?php } ?>	
		
			</table>  
        </div>  
	</div>  
	</div>
    <br>
	</section>
<!-- Section Social
================================================== -->
<section id = "service">
<div class = "container">
<div class = "row">
		<div class = "table-scrol">  
		<h1 align = "center">Service Providers Request for Account</h1>
	  
		<div class = "table-responsive"><!--this is used for responsive display in mobile and other devices-->  
	  
	  
		<table class = "table table-bordered table-hover table-striped" style = "table-layout: fixed">  
				<thead>  
		  
				<tr> 
					<th>First Name</th> 
					<th>Last Name</th>			
					<th>Username</th>  
					<th>Gender</th>
					<th>Address</th>
					<th>Country</th>
					<th>Phone Number</th>
					<th>Email</th>
					
				</tr>  
				</thead>  
		  
				<?php  
					include("db_conection.php");  
					$view_salon_query = "select * from service_provider";//select query for viewing users.  
					$run = mysqli_query($dbcon,$view_service_provider_query);//here run the sql query.  
			  
					while($row = mysqli_fetch_array($run))//while look to fetch the result and store in a array $row.  
					{  
						$service_id = $row[0];
						$service_firstname = $row[1];						
						$service_lastname = $row[2];
						$service_nickname = $row[3];
						$address = $row[4];
						$country = $row[5];
						$service_contact_no = $row[6];
						$service_email = $row[7];
						
				?>  
		  
				<tr>  
		<!--here showing results in the table -->  
					<td><?php echo $service_firstname;  ?></td> 
					<td><?php echo $service_lastname;  ?></td>   
					<td><?php echo $service_username;  ?></td> 
					<td><?php echo $address;  ?></td>
					<td><?php echo $country;  ?></td>
					<td><?php echo $service_contact_no;  ?></td>
					<td><?php echo $service_email;  ?></td> 					
					
					<td><a href = "accept_sp.php?accept_sp = <?php echo $service_id ?>"><button onclick = "block_none()">Accept</button></a>
					<a href = "delete_sp.php?del = <?php echo $service_id ?>"><button onclick = "block_none()">Reject</button></a></td> <!--btn btn-danger is a bootstrap button to show danger-->  
						
				</tr>  
					<?php } ?>
			</table>  
        </div>  
	</div> 
    </div>
    <br>
	</div>
	</div>
</section>

<!-- Section Timeline
================================================== -->
<section id = "accounts">
<div class = "container">
<div class = "row">
		<div class = "table-scrol">  
		<h1 align = "center">Customers</h1>
	  
		<div class = "table-responsive"><!--this is used for responsive display in mobile and other devices-->  
	  
	  
		<table class = "table table-bordered table-hover table-striped" style = "table-layout: fixed">  
				<thead>   
		  
				<tr>
					<th>First Name</th>					
					<th>Last Name</th>
					<th>Username</th>
					<th>Gender</th>					
					<th>Address</th> 
					<th>E-mail</th>
					<th>Country</th>							
					<th>Contact Number</th>
					
				</tr>  
				</thead>  
		  
				<?php  
					include("db_conection.php");  
					$view_salon_query = "select * from users";//select query for viewing users.
					$run = mysqli_query($dbcon,$view_users_query);//here run the sql query.  
			  
					while($row = mysqli_fetch_array($run))//while look to fetch the result and store in a array $row.  
					{  

						$user_id = $row[0];
						$firstname = $row[1];						
						$lastname = $row[2];
						$username = $row[3];
						$gender = $row[4];
						$address = $row[5];
						$email = $row[6]; 
						$country = $row[7];
						$contact_no = $row[8];
				?>  
		  
				<tr>  
		<!--here showing results in the table -->  

					<td><?php echo $firstname;  ?></td>
					<td><?php echo $lastname;  ?></td>    
					<td><?php echo $username;  ?></td> 
					<td><?php echo $gender;  ?></td>
					<td><?php echo $address;  ?></td>
					<td><?php echo $email;  ?></td> 
					<td><?php echo $country;  ?></td>
					<td><?php echo $contact_no;  ?></td> 
						
						
		
			</table>  
        </div>  
	</div>  
	</div>
    <br>
	</section>
<!-- Section Social
================================================== -->
<section id = "accounts">
<div class = "container">
<div class = "row">
		<div class = "table-scrol">  
		<h1 align = "center">Service Providers</h1>
	  
		<div class = "table-responsive"><!--this is used for responsive display in mobile and other devices-->  
	  
	  
		<table class = "table table-bordered table-hover table-striped" style = "table-layout: fixed">  
				<thead>  
		  
				<tr> 
					<th>First Name</th> 
					<th>Last Name</th>			
					<th>Username</th>  
					<th>Gender</th>
					<th>Address</th>
					<th>Country</th>
					<th>Contact Number</th>
					<th>Email</th>
					
				</tr>  
				</thead>  
		  
				<?php  
					include("db_conection.php");  
					$view_salon_query = "select * from service_providers";//select query for viewing users.  
					$run = mysqli_query($dbcon,$view_service_provider_query);//here run the sql query.  
			  
					while($row = mysqli_fetch_array($run))//while look to fetch the result and store in a array $row.  
					{  
						$service_id = $row[0];
						$service_firstname = $row[1];						
						$service_lastname = $row[2];
						$service_username = $row[3];
						$service_address = $row[4];
						$service_contact_no = $row[5];
						$service_email = $row[6];
						
				?>  
		  
				<tr>  
		<!--here showing results in the table -->  
					<td><?php echo $service_firstname;  ?></td> 
					<td><?php echo $service_lastname;  ?></td>   
					<td><?php echo $service_username;  ?></td> 
					<td><?php echo $service_address;  ?></td>
					<td><?php echo $service_contact_no;  ?></td>
					<td><?php echo $service_email;  ?></td>	
					
				</tr>  
					<?php } ?>
			</table>  
        </div>  
	</div> 
    </div>
    <br>
	</div>
	</div>
</section>

<!-- Section Footer
================================================== -->
<section class = "bg-dark">
<div class = "container">
<div class = "row">
	<div class = "col-md-12 text-center">
		<h1 class = "bottombrand wow flipInX">Aling bebe</h1>
		<p>
			&copy; Webtech Lab 2018 
		</p>
	</div>
</div>
</div>
</section>


    
</body>
</html>