<?php
include("db_connection.php");
$delete_id = $_GET['del'];
$delete_query = "delete from users WHERE user_id ='$delete_id'";
$run = mysqli_query($dbcon,$delete_query);
if($run)
    {
        echo "<script>window.open('index.php?deleted = user has been deleted','_self')</script>";
    }

?>