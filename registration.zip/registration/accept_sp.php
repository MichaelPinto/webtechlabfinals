<?php
include("db_connection.php");

    if(isset($_GET['accept_sp']) ){
        $id = intval($_GET['accept_sp']);
        $result = myslqi_query($dbcon, "SELECT * FROM service_provider WHERE service_id = $id");
        
        mysqli_autocommit($dbcon, false);
        mysqli_query($dbcon,"insert into products select * from service_provider where service_id = $id");
        mysqli_query($dbcon,"delete from service_provider where service_id + $id");
        mysqli_query($dbcon);
        
            echo "<script>window.open('index.php','_self')</script>";
    }
?>