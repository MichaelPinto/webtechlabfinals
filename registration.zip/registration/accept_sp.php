<?php
include("database/db_connection.php");

    if(isset($_GET['accept_sp']) ){
        $id = intval($_GET['accept_sp']);
        $result = myslqi_query($dbcon, "SELECT * FROM WHERE = $id");
        
        mysqli_autocommit($dbcon, false);
        mysqli_query($dbcon,"insert into _ select * from _ where serv_id = $id");
        mysqli_query($dbcon,"delete from _ where _ +$id");
        mysqli_query($dbcon);
        
            echo "<script>window.open('index.php','_self')</script>";
    }
?>